#include "Creator.h"



//Figure_Parent Creator::FactoryMethod(int x,int y)
//{
//	return nullptr;
//}

Creator::Creator()
{

}


Creator::~Creator()
{
}

//
//Creator::Creator(const Creator& obj)
//{
//
//}
//Creator& Creator::operator=(const Creator& obj)
//{
//
//}