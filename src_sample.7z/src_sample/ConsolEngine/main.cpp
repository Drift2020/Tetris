// Copyright 2009-2014 Blam Games, Inc. All Rights Reserved.

#include "Game.h"

void main ()
{

	Game app= Game();
	app.Run();
	
}
